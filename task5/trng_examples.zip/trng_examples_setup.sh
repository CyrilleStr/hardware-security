# git clone https://github.com/patrickhaddadteaching/TRNG_ex1
# git clone https://github.com/patrickhaddadteaching/TRNG_ex2
# git clone https://github.com/patrickhaddadteaching/TRNG_ex3
# git clone https://github.com/patrickhaddadteaching/TRNG_ex4
# git clone https://github.com/patrickhaddadteaching/TRNG_ex5
# py -m pip install h5py jupyter numpy matplotlib scipy voila
# export PATH=$PATH:`cygpath $APPDATA`/Python/Python310/Scripts
export PATH=$PATH:/c/Program\ Files/Python310/Scripts:`cygpath $APPDATA`/Python/Python310/Scripts
export JUPYTER_ALLOW_INSECURE_WRITES=1
jupyter-notebook
bash
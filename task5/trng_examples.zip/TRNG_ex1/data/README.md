directory with precomputed values
